public interface formulaStrategy {
    public double formula(SmartDevice sd);
}
